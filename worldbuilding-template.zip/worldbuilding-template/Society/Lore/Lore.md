---
tags:
- society
- lore
- category
---
# Lore
In-world stories, folklore, and other commonly shared information within the world should be documented here.
# Table of Contents
%% Begin Waypoint %%


%% End Waypoint %%
