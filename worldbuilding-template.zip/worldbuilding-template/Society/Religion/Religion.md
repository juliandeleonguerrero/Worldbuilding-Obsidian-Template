---
tags:
- religion
- society
- category
---
# Religion
Religions themselves should be noted here- though there may be heavy overlap between religious groups, and the gods themselves. Heavy embedding of other article sections may be useful within articles here.
# Table of Contents
%% Begin Waypoint %%


%% End Waypoint %%
