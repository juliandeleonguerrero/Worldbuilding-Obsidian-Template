---
tags:
- customs
- society
- category
---
# Customs
Customs can include customs and traditions, common cultural practices, and other learned activities within the society.
# Table of Contents
%% Begin Waypoint %%


%% End Waypoint %%
