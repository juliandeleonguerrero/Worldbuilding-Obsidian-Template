---
tags:
- material
- afflict
- category
---
# Afflictions
Notes on disease, pestilence, and infection can be stored here.
# Table of Contents
%% Begin Waypoint %%


%% End Waypoint %%
