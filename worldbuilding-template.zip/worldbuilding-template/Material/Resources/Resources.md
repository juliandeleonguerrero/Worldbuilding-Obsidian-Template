---
tags:
- resource
- material
- category
---
# Resources
Information about iron, coal, wood, or your fantasy unobtainium of choice can be stored here.
# Table of Contents
%% Begin Waypoint %%


%% End Waypoint %%