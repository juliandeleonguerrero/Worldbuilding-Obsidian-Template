---
tags:
- physic
- material
- category
---
# Metaphysics
Do the foundational physical laws of your fantasy world vary from the real world? If so, that information can be stored here.
# Table of Contents
%% Begin Waypoint %%


%% End Waypoint %%
