---
tags:
- material
- magic
- category
---
# Magic
Interesting spells, rituals, and the laws of magic itself can be stored here.
# Table of Contents
%% Begin Waypoint %%


%% End Waypoint %%
