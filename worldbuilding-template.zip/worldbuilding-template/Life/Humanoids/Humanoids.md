---
tags:
- specie
- humanoid
- life
- category
---
# Humanoid Species
Humanoid species, sometimes called "races" in some TTRPGs can be stored here. This may include creatures such as humans, elves, dwarves, or orcs.