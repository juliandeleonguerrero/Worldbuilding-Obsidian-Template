---
tags:
- life
- magic
- category
---
# Magical
Magical species such as dragons, slimes, or undead might go here.

# Table of Contents
%% Begin Waypoint %%


%% End Waypoint %%
