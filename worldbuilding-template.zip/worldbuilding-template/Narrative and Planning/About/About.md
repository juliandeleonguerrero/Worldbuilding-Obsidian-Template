---
tags:
- about
- narrate
- plan
- category
---
# About
The About Folder can contain the overarching information about your world. It is meant to contain basic summaries about major facts in your fantasy world. This might include basic information about its history, interesting world-specific conceits, and other fun ideas or mechanics introduced in your worldbuilding.
# Table of Contents
%% Begin Waypoint %%


%% End Waypoint %%
