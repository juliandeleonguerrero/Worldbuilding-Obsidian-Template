---
tags:
- narrate
- category
---
# Storylines
This folder is meant to contain story arcs, ongoing plots, and other information meant to help you outline what is happening in your world.

Because preferences in how to organize this can vary among writers, this section has been left blank. If you find yourself making a similarly structured document over and over for this section, it is recommended you make an appropriate template in the Templates folder.
# Table of Contents
%% Begin Waypoint %%


%% End Waypoint %%
