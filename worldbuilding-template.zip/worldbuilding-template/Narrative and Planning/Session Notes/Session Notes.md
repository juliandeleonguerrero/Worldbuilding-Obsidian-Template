---
tags:
- narrate
- category
---
# Session Notes
This folder is meant to help track session notes for world builders creating worlds for tabletop roleplaying games (TTRPGs), such as Pathfinder or GURPS.

World builders using this template for storywriting purposes outside of TTRPGs may wish to delete this folder.
# Table of Contents
%% Begin Waypoint %%


%% End Waypoint %%
