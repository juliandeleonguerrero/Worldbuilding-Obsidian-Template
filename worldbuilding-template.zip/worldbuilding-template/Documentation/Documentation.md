---
tags:
- doc
- category
---
# Documentation
The documentation folder exists to outline useful tips for managing and using the worldbuilding template. It also includes links to documentation for the plugins/theme used for this template.
# Table of Contents
%% Begin Waypoint %%
- [[Getting Started]]
- **Images**
- [[Plugins and Theme]]

%% End Waypoint %%
