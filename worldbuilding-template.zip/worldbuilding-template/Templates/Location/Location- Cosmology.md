---
tags:
- location
- space
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Location Type |   |
> | ---- | ---- |
> | Other Titles |  |
> | Size |  |
> | Prominent locations within {{title}} |   |
# Description
## About

## Geography

## Ecology

## Populations

## Climate

# History

# Significant locations in {{title}}

# Other Notes
