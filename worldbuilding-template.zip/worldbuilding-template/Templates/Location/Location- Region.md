---
tags:
- location
- region
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Location Type |   |
> | ---- | ---- |
> | Other Titles |  |
> | Area |  |
> | Prominent locations within {{title}} |   |
# Description
## About

## Features

## Ecology

## Populations

## Climate

# History

# Significant locations in {{title}}

# Other Notes
