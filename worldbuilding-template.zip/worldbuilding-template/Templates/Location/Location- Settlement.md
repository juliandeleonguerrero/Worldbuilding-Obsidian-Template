---
tags:
- location
- settle
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Type of Settlement |  |
> | ---- | ---- |
> | Continent |  |
> | Government |  |
> | Population | |
> | Size |  |
> | Languages |  |
> | Currencies |  |
> | Humankind |  |
> | Industries |   |
> | Religion |   |
# Description

# History

# Culture

# Significant locations in {{title}}

# Residents

# Other Notes
