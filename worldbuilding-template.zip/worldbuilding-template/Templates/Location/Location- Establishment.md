---
tags:
- location
- establish
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Location Type |   |
> | ---- | ---- |
> | Other Titles |  |
> | Location |  |
> | Opened/Built |   |
> | Owner |   |
> | Status |   |

# Description

# History

# Other Notes
