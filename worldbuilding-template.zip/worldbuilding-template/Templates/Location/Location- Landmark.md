---
tags:
- location
- landmark
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Location Type |   |
> | ---- | ---- |
> | Other Titles |  |
> | Region |  |
> | Size |  |

# Description

# History

# Significant locations in {{title}}

# Other Notes
