---
tags:
- material
- object
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Object Type |   |
> | ---- | ---- |
> | Other Titles |  |
> | Value |   |
> | Location |   |
> | Owner |  |
> | Origin |   |

# {{Title}}

# History

# Associated Lore
