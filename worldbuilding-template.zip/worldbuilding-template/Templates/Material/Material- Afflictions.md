---
tags:
- material
- afflict
---
# {{Title}}

## Cause

## Symptoms

# History
