---
tags:
- material
- magic
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Magical Concept |   |
> | ---- | ---- |
> | Type of Magic |  |
> | Power Level |  |
# {{Title}}
