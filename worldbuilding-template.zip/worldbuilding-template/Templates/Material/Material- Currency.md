---
tags:
- material
- currency
- econ
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Currency of |   |
> | ---- | ---- |
> | Currency Form |  |
> | Used in |  |
> | Issuer/Minter |   |

# {{Title}}

# History
