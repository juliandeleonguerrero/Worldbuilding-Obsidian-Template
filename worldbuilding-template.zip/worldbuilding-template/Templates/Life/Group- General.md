---
tags:
- general
- group
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Type |  |
> | ---- | ---- |
> | Other Titles |  |
> | Headquarters | |
> | Leader(s) |  |
> | Member Count |   |
| Ideology/Beliefs |   |
> | Languages |  |
> | Status |  |

# Description

# History

# Organization
