---
tags:
- life
- humanoid
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Other Titles |   |
> | ---- | ---- |
> | Origin |  |
> | Area(s) |  |
> | Subspecies |   |
> | Population |   |
> | Lifespan |   |
>  ###### Appearance
>  | Type of Traits | Commonly |
>  | ---- | ---- |
>  | Skin Color(s) |   |
>  | Hair Color(s) |   |
>  | Eye Color(s) |   |
>  | Typical Build |   |
>  | Other Traits |   |
>  | Average Weight |   |

# {{Title}}

# Biology

# Society

# Culture

# History
