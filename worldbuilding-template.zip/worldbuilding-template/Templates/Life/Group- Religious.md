---
tags:
- religious
- group
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Type |  |
> | ---- | ---- |
> | Other Titles |  |
> | Headquarters/Capital | |
> | Origin |  |
> | Leader(s) |  |
> | Member Count |   |
| Ideology/Beliefs |   |
> | Languages |  |
> | Status |  |

# Description

# History

# Organization
