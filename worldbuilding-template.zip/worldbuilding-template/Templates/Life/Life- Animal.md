---
tags:
- life
- animal
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Type of Animal |   |
> | ---- | ---- |
> | Diet |  |
> | Area |  |
> | Subspecies |   |
> | Population |   |

# {{Title}}s

# Distribution and Habitat

# Behavior and Ecology

# Cultural Significance
