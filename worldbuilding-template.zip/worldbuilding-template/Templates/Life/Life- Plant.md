---
tags:
- life
- plant
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Type of Plant |   |
> | ---- | ---- |
> | Grows in |  |
> | Subspecies |   |
> | Rarity |   |
# {{Title}}

# Distribution and Ecosystem

# Cultural Significance
