---
tags:
- combat
- group
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Type |  |
> | ---- | ---- |
> | Other Titles |  |
> | Member Count |   |
> | Headquarters/Base | |
> | Leader(s) |  |
> | Languages |  |
> | Status |  |

# Description
## About

## Abilities

# History

# Organization

