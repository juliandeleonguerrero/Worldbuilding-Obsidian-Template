---
tags:
- life
- magic
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Type of Creature |   |
> | ---- | ---- |
> | Diet |  |
> | Area |  |
> | Subspecies |   |
> | Population |   |
# {{Title}}

# Distribution and Habitat

# Behavior and Ecology

# Cultural Significance
