---
tags:
- character
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Titles |  |
> | ---- | ---- |
> | Gender |  |
> | Species |  |
> | Occupation/Class | |
> | Residence |  |
> | Birthplace |  |
> | Birth Date |   |
> | Status |  |
> | Languages |  |
> | Relatives |   |
# About {{Title}}

# History

# Appearance

# Relationships
| Characters | Relationship | Notes |
| ---------- | ------------ | ----- |
|            |              |       |
|            |              |       |

# Abilities

# Other Notes
