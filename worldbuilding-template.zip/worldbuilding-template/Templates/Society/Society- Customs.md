---
tags:
- customs
- society
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Type of Custom/Tradition |   |
> | ---- | ---- |
> | Other Titles |  |
> | Frequency |  |
> | Participants |   |
# {{Title}}

# History
