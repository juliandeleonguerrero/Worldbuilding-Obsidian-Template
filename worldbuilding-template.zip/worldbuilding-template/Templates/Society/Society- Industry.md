---
tags:
- customs
- society
---
> [!infobox]
> # `{{Title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Type of Industry/Industrial Practice |   |
> | ---- | ---- |
> | Other Titles |  |
> | Frequency |  |
> | Participants |   |
# {{Title}}

# History
