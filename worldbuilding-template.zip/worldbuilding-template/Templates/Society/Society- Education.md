---
tags:
- edu
- society
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Type of Theory/Discipline |   |
> | ---- | ---- |
> | Subject Field |   |
> | Origin |   |

# {{Title}}

# History

# Impact
