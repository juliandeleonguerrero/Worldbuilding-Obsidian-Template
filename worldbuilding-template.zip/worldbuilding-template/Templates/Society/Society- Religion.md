---
tags:
- society
- religion
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Type of Faith |   |
> | ---- | ---- |
> | God(s) Worshipped |  |
> | Members |  |
> | Prominent Scriptures |   |
> | Region(s) |   |
> | Founder |   |
> 
# {{Title}}

# Description

# Culture

## Beliefs

## Practices

## Holidays

## Important Media

## Symbols
