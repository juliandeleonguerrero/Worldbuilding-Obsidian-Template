---
tags:
- art
- society
---
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### About
> | Type of Art |   |
> | ---- | ---- |
> | Other Titles |  |
> | Creator |   |
> | Owner |   |
> | Location |  | 
# {{Title}}
