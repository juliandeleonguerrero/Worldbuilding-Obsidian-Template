---
tag:
- event
- timeline
---
<span 
	  class='ob-timelines' 
	  data-date='2000-10-10-00' 
	  data-title='{{title}}' 
	  data-class='orange' 
	  data-img = 'Timeline Example/Timeline_2.jpg' 
	  data-type='range' 
	  data-end='2000-10-20-00'> 
</span>
> [!infobox]
> # `{{title}}`
> ![[Image.png|cover hsmall]]
> ###### Details
> | Event Type |  |
> | ---- | ---- |
> | Date Started |  |
> | Date Ended |  |
> | Prominent Actors |  |
> | Location |  |
> | Result |  |
# Background

# Description

# Aftermath

